package integration.gui.mock.component;

import mdlaf.themes.JMarsDarkTheme;

public class ThemeExampleChangeTabHeight extends JMarsDarkTheme {

	@Override
	public int getHeightTabTabbedPane() {
		return 25;
	}
}

